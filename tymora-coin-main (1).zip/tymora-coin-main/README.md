# tymora-coin

This module is an example of how to add a set of custom coin faces to the Dice So Nice module for FoundryVTT.

Made for https://old.reddit.com/r/FoundryVTT/comments/vga3bf/any_way_to_customise_the_coinflip_dc_roll/
